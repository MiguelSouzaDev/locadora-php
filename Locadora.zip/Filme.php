<?php
class Filme{
        //atributos
        private $id;
        private $titulo;
        private $genero;
        private $ano;
        private $disponivel;
        
        //construtor
        function __construct($id, $titulo, $genero, $ano, $disponivel = true){
            $this->id = $id;
            $this->titulo = $titulo;
            $this->genero = $genero;
            $this->ano = $ano;
            $this->disponivel = $disponivel;
        }
        
        //getters
        function getId(){
            return $this->id;
        }
        function getTitulo(){
            return $this->titulo;
        }
        function getGenero(){
            return $this->genero;
        }
        function getAno(){
            return $this->ano;
        }
        function getDisponivel(){
            return $this->disponivel;
        }
        
        //setters
        function setId($id){
            $this->id = $id;
        }
        function setTitulo($titulo){
            $this->titulo = $titulo;
        }
        function setGenero($genero){
            $this->genero = $genero;
        }
        function setAno($ano){
            $this->ano = $ano;
        }
        function setDisponivel($disponivel){
            $this->disponivel = $disponivel;
        }
        
        //métodos
        function marcarComoAlugado(): void{
            $this->disponivel = false;
        }
        function marcarComoDisponivel(): void{
            $this->disponivel = true;
        }
    }
    ?>