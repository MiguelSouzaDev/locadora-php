<?php
class Locadora {
    //atributos
    private array $filmes = [];
    private array $clientes = [];
    private array $locacoes = [];

    //métodos
    function cadastrarFilme(Filme $filme): void {
        $this->filmes[] = $filme;
    }
    function cadastrarCliente(Cliente $cliente): void {
        $this->clientes[] = $cliente;
    }
    function listarFilmesDisponiveis(): array {
        return array_filter($this->filmes, fn($filme) => $filme->getDisponivel());
    }
    function alugarFilme(Cliente $cliente, Filme $filme): ?Locacao {
        if (!$filme->getDisponivel()) {
            echo "Filme não disponível.\n";
            return null;
        }
        $filme->marcarComoAlugado();
        $locacao = new Locacao(
            count($this->locacoes) + 1,
            $cliente,
            $filme,
            new DateTime(),
            null
        );
        $this->locacoes[] = $locacao;
        return $locacao;
    }
    function devolverFilme(Locacao $locacao): void {
        $locacao->devolverFilme();
        $multa = $locacao->calcularMulta();
        echo "Filme devolvido com sucesso. Multa: R$" . number_format($multa, 2, ',', '.') . "\n";
    }
    function listarLocacoes(): array {
        return $this->locacoes;
    }
    function getClientes(): array {
    return $this->clientes;
}

}
?>