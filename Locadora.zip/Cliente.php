<?php
class Cliente{
        //atributos
        private $id;
        private $nome;
        private $CPF;
        private $telefone;
        
        //construtor
        function __construct($id, $nome, $CPF, $telefone){
            $this->id = $id;
            $this->nome = $nome;
            $this->CPF = $CPF;
            $this->telefone = $telefone;
        }
        
        //getters
        function getId(){
            return $this->id;
        }
        function getNome(){
            return $this->nome;
        }
        function getCPF(){
            return $this->CPF;
        }
        function getTelefone(){
            return $this->telefone;
        }
        
        //setters
        function setId($id){
            $this->id = $id;
        }
        function setNome($nome){
            $this->nome = $nome;
        }
        function setCPF($CPF){
            $this->CPF = $CPF;
        }
        function setTelefone($telefone){
            $this->telefone = $telefone;
        }
    }
    ?>