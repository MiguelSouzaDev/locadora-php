<?php
    require_once "Filme.php";
    require_once "Locacao.php";
    require_once "Cliente.php";
    require_once "Locadora.php";

    session_start();
  
    if(!isset($_SESSION['locadora'])){
        $_SESSION['locadora'] = new Locadora();
    }

    $locadora = $_SESSION['locadora'];

    if (isset($_POST['cadastrar_filme'])) {
    $titulo = $_POST['titulo'];
    $genero = $_POST['genero'];
    $ano = $_POST['ano'];

    $id = count($locadora->listarFilmesDisponiveis()) + 1;

    $filme = new Filme($id, $titulo, $genero, $ano);
    $locadora->cadastrarFilme($filme);
}

    if (isset($_POST['cadastrar_cliente'])) {
    $nome = $_POST['nome'];
    $cpf = $_POST['cpf'];
    $telefone = $_POST['telefone'];
    $id = count($locadora->listarLocacoes()) + 1;

    $cliente = new Cliente($id, $nome, $cpf, $telefone);
    $locadora->cadastrarCliente($cliente);

}

    if (isset($_POST['alugar_filme'])) {
    $clienteId = $_POST['cliente_id'];
    $filmeId = $_POST['filme_id'];

    $cliente = null;
    foreach ($locadora->getClientes() as $c) {
        if ($c->getId() == $clienteId) {
            $cliente = $c;
            break;
        }
    }

    $filme = null;
    foreach ($locadora->listarFilmesDisponiveis() as $f) {
        if ($f->getId() == $filmeId) {
            $filme = $f;
            break;
        }
    }

    if ($cliente && $filme) {
        $locadora->alugarFilme($cliente, $filme);
    }
}

    if (isset($_POST['devolver_filme'])) {
    $locacaoId = $_POST['locacao_id'];

    foreach ($locadora->listarLocacoes() as $locacao) {
        if ($locacao->getId() == $locacaoId && $locacao->getDataDevolucao() === null) {
            $locadora->devolverFilme($locacao);
            $multa = $locacao->calcularMulta();
            echo "<p>Filme devolvido. Multa: R$ " . number_format($multa, 2, ',', '.') . "</p>";
            break;
        }
    }
}
?>

<!DOCTYPE html>
<html lang = "pt br">

<head>
    <meta charset = "UTF-8">
    <title>Locadora</title>
</head>
<body>
      <h2>Cadastrar Filme</h2>
  <form method="post">
    <input type="text" name="titulo" placeholder="Título" required>
    <input type="text" name="genero" placeholder="Gênero" required>
    <input type="number" name="ano" placeholder="Ano" required>
    <button type="submit" name="cadastrar_filme">Cadastrar</button>
  </form>

     <h2>Filmes Disponíveis</h2>
  <ul>
  <?php foreach ($locadora->listarFilmesDisponiveis() as $filme): ?>
    <li><?= $filme->getTitulo() ?> (<?= $filme->getAno() ?>) - <?= $filme->getGenero() ?></li>
  <?php endforeach; ?>
  </ul>

    <h2>Cadastrar Cliente</h2>
<form method="post">
  <input type="text" name="nome" placeholder="Nome" required>
  <input type="text" name="cpf" placeholder="CPF" required>
  <input type="text" name="telefone" placeholder="Telefone" required>
  <button type="submit" name="cadastrar_cliente">Cadastrar</button>
</form>

    <h2>Alugar Filme</h2>
<form method="post">
  <select name="cliente_id" required>
    <option value="">Selecione o cliente</option>
    <?php foreach ($locadora->getClientes() as $cliente): ?>
      <option value="<?= $cliente->getId() ?>"><?= $cliente->getNome() ?></option>
    <?php endforeach; ?>
  </select>

  <select name="filme_id" required>
    <option value="">Selecione o filme</option>
    <?php foreach ($locadora->listarFilmesDisponiveis() as $filme): ?>
      <option value="<?= $filme->getId() ?>"><?= $filme->getTitulo() ?></option>
    <?php endforeach; ?>
  </select>

  <button type="submit" name="alugar_filme">Alugar</button>
</form>

        <h2>Locações Ativas</h2>
<ul>
<?php foreach ($locadora->listarLocacoes() as $locacao): ?>
  <?php if ($locacao->getDataDevolucao() === null): ?>
    <li>
      <?= $locacao->getFilme()->getTitulo() ?> alugado por <?= $locacao->getCliente()->getNome() ?> em <?= $locacao->getDataLocacao()->format('d/m/Y') ?>
      <form method="post" style="display:inline;">
        <input type="hidden" name="locacao_id" value="<?= $locacao->getId() ?>">
        <button type="submit" name="devolver_filme">Devolver</button>
      </form>
    </li>
  <?php endif; ?>
<?php endforeach; ?>
</ul>

</body>
</html>