 <?php
 class Locacao{
        //atributos
        private $id;
        private $cliente;
        private $filme;
        private DateTime $dataLocacao;
        private ?DateTime $dataDevolucao;
        
        //construtor
        function __construct($id, $cliente, $filme, DateTime $dataLocacao, ?DateTime $dataDevolucao){
            $this->id = $id;
            $this->cliente = $cliente;
            $this->filme = $filme;
            $this->dataLocacao = $dataLocacao;
            $this->dataDevolucao = $dataDevolucao;
        }
        
        //getters
        function getId(){
            return $this->id;
        }
        function getCliente(){
            return $this->cliente;
        }
        function getFilme(){
            return $this->filme;
        }
        function getDataLocacao(){
            return $this->dataLocacao;
        }
        function getDataDevolucao(){
            return $this->dataDevolucao;
        }
        
        //setters
        function setId($id){
            $this->id = $id;
        }
        function setCliente($cliente){
            $this->cliente = $cliente;
        }
        function setFilme($filme){
            $this->filme = $filme;
        }
        function setDataLocacao($dataLocacao){
            $this->dataLocacao = $dataLocacao;
        }
        function setDataDevolucao($dataDevolucao){
            $this->dataDevolucao = $dataDevolucao;
        }
        
        //métodos
        function devolverFilme(): void{
            $this->dataDevolucao = new DateTime();
            $this->filme->marcarComoDisponivel();
        }
        function calcularMulta(): float{
            $prazoDias = 3;
            $multaPorDia = 2.00;
            $dataPrevista = clone $this->dataLocacao;
            $dataPrevista->modify("+{$prazoDias} days");
            $hoje = $this->dataDevolucao ?? new DateTime();
            if ($hoje > $dataPrevista){
            $diasAtraso = $dataPrevista->diff($hoje)->days;
            return $diasAtraso * $multaPorDia;
            }

            return 0.0;
        }
    }
    ?>